import gymnasium as gym
from gymnasium import spaces
import numpy as np
import rasterio
import yaml
import os
from scipy.ndimage import uniform_filter

class ForestFireEnv(gym.Env):
    """
    Custom Gymnasium environment for wildfire suppression
    in the Sierra Nevada region using Cell2Fire as the
    fire spread physics engine.

    State:  (height, width, 9) tensor
            channels: fuel, fire, water, buildings,
                      wind, elevation, humidity, slope, aspect

    Action: Discrete — index of grid cell to spray water on
    """

    metadata = {"render_modes": ["human"]}

    def __init__(self, config_path=r'/content/drive/MyDrive/FOREST FIRE RL/fire_sim/config.yaml', render_mode=None):

        super().__init__()
        self.render_mode = render_mode

        # Load config 
        with open(config_path, "r") as f:
            self.cfg = yaml.safe_load(f)
                                                                                                                              
        # Grid dimensions  
        self.height = self.cfg["grid"]["height"]
        self.width  = self.cfg["grid"]["width"]
        self.n_cells = self.height * self.width
        self.n_channels = 9

        # Action space: This tell our model there number of possible actions that can be taken for each timestep (17689)
        # Agent picks one cell per timestep to spray water on
        self.action_space = spaces.Discrete(self.n_cells)

        # Observation space: A count of all the individual observation across the 64x64 grid
        # 9 channels, all normalised to [0, 1]
        # Flatten observation to 1D vector — avoids image interpretation by SB3
        self.observation_space = spaces.Box(
            low   = 0.0,
            high  = 1.0,
            shape = (self.n_channels, self.height, self.width),
            dtype = np.float32
        )

        # Load static terrain layers from our california map
        self.fuel_map      = self._load_raster(self.cfg["terrain"]["fuel_path"])
        self.slope_map     = self._load_raster(self.cfg["terrain"]["slope_path"])
        self.aspect_map    = self._load_raster(self.cfg["terrain"]["aspect_path"])
        self.elevation_map = self._load_raster(self.cfg["terrain"]["elevation_path"])

        # Fixed environment values (could be dynamic but fixed for ease of training)
        self.wind_speed       = self.cfg["environment"]["wind_speed"]
        self.wind_direction   = self.cfg["environment"]["wind_direction"]
        self.humidity         = self.cfg["environment"]["humidity"]
        self.building_density = self.cfg["environment"]["building_density"]

        # Dynamic layers (reset each episode) 
        self.fire_map  = None
        self.water_map = None

        # Step counter  
        self.step_count  = 0
        self.max_steps   = 200
    
    def _load_raster(self, path):
        """Load a single-band raster and normalise to [0, 1]."""
        with rasterio.open(path) as src:
            data = src.read(1).astype(np.float32)
            nodata = src.nodata
            if nodata is not None:
                data[data == nodata] = 0.0
            data[data == -9999] = 0.0

        # Resize to match config grid size if needed
        from skimage.transform import resize
        data = resize(data, (self.height, self.width),
                      anti_aliasing=True).astype(np.float32)

        # Normalise to [0, 1]
        dmin, dmax = data.min(), data.max()
        if dmax > dmin:
            data = (data - dmin) / (dmax - dmin)
        return data 
    
    def reset(self, seed=None, options=None):
        """
        Start a new episode:
        - Clear fire and water maps
        - Pick a random ignition cell
        - Return initial state
        """
        super().reset(seed=seed)

        self.step_count = 0

        # Reset dynamic layers
        # Fire states: 0 = unburned, 1 = burning, 2 = burned out
        self.fire_map  = np.zeros((self.height, self.width), dtype=np.float32)
        self.water_map = np.zeros((self.height, self.width), dtype=np.float32)
        self.spray_count = np.zeros((self.height, self.width), dtype=np.int32)

        # Random ignition point 
        # Avoid edges (5 cell buffer) so fire has room to spread
        ig_row = np.random.randint(5, self.height - 5)
        ig_col = np.random.randint(5, self.width  - 5)
        self.fire_map[ig_row, ig_col] = 1.0

        # Track stats
        self.initial_fire_cell = (ig_row, ig_col)
        self.total_burned      = 0
        self.total_suppressed  = 0

        return self._get_obs(), {}


    def _get_obs(self):
        from scipy.ndimage import uniform_filter

        # Compute neighbour fire channel on the fly
        # Identical calculation to _spread_fire() — counts burning neighbours per cell
        burning = (self.fire_map == 1.0)
        neighbour_channel = uniform_filter(
            burning.astype(np.float32),
            size=3,
            mode='constant',
            cval=0.0
        )
        # Remove centre cell — only neighbours count
        neighbour_channel = np.clip(neighbour_channel * 9 - burning, 0, 8) / 8.0

        obs = np.stack([
            self.fuel_map,                                  # ch 0 — fuel terrain
            self.fire_map / 2.0,                            # ch 1 — fire state
            self.water_map,                                 # ch 2 — water deployed
            self.slope_map,                                 # ch 3 — slope terrain
            self.aspect_map,                                # ch 4 — aspect terrain
            (self.spray_count > 0).astype(np.float32),     # ch 5 — cells sprayed once
            (self.spray_count >= 2).astype(np.float32),    # ch 6 — cells sprayed 2+ times
            self.elevation_map,                             # ch 7 — elevation
            neighbour_channel,                              # ch 8 — burning neighbours
        ], axis=0).astype(np.float32)

        return obs
    
    def step(self, action):
        """
        Execute one timestep:
        1. Agent sprays water on chosen cell
        2. Fire spreads via propagation formula
        3. Compute reward
        4. Check if episode is done
        """
        self.step_count += 1

        # Decode action → grid cell
        row = action // self.width
        col = action  % self.width

        # Track state before spread
        prev_burning = np.sum(self.fire_map == 1.0)
        prev_burned  = np.sum(self.fire_map == 2.0)

        # Record whether chosen cell was burning BEFORE water applied
        was_burning = (self.fire_map[row, col] == 1.0)

        # Apply water to chosen cell
        self.water_map[row, col] = min(
            self.water_map[row, col] + 0.5, 1.0
        )

        # Suppress fire if water hits a burning cell
        if self.fire_map[row, col] == 1.0 and self.water_map[row, col] >= 0.5:
            self.fire_map[row, col] = 0.0
            self.total_suppressed += 1

        # Spread fire one timestep
        self._spread_fire()

        # Update counts after spread
        curr_burning = np.sum(self.fire_map == 1.0)
        curr_burned  = np.sum(self.fire_map == 2.0)
        new_burned   = curr_burned - prev_burned
        self.total_burned = int(curr_burned)

        # Compute reward
        reward = self._compute_reward(
            row, col, new_burned, prev_burning, curr_burning, was_burning
        )

        # Check termination
        burned_pct = curr_burned / self.n_cells
        terminated = bool(
            curr_burning == 0 or    # fire fully out
            burned_pct   > 0.5      # >50% of grid burned
        )
        truncated = self.step_count >= self.max_steps

        info = {
            "step":       self.step_count,
            "burning":    int(curr_burning),
            "burned":     int(curr_burned),
            "suppressed": self.total_suppressed,
            "burned_pct": round(burned_pct, 3),
        }

        return self._get_obs(), reward, terminated, truncated, info


    def _spread_fire(self):

        cfg   = self.cfg["fire"]
        alpha = cfg["alpha"]
        gamma = cfg["gamma"]
        delta = cfg["delta"]

        wind_influence = self.wind_speed / 100.0

        # ── Step 1: find all currently burning cells ──────────────
        burning = (self.fire_map == 1.0)

        # ── Step 2: count burning neighbours for every cell ───────
        # uniform_filter sums the 3x3 neighbourhood for every cell
        # simultaneously — no Python loops needed
        neighbour_fire = uniform_filter(
            burning.astype(np.float32),
            size=3,
            mode='constant',
            cval=0.0
        )
        # Remove centre cell — only count neighbours not self
        neighbour_fire = np.clip(neighbour_fire * 9 - burning, 0, 8) / 8.0

        # ── Step 3: cells with NO burning neighbours cannot ignite ─
        # This enforces connected fire spread — fire cannot
        # randomly teleport to isolated cells across the grid
        has_burning_neighbour = neighbour_fire > 0.0

        # ── Step 4: slope multiplier ───────────────────────────────
        # Fire spreads faster uphill — from propagation formula
        # F(t+1) = F(t) + alpha * N(i,j) * W_wind * (1+gamma*Slope) * Fuel
        slope_multiplier = 1.0 + gamma * self.slope_map

        # ── Step 5: compute spread probability for every cell ─────
        # P_spread = sigmoid(theta1*F + theta2*Wind + theta3*Fuel*Slope
        #                  + theta4*Slope + theta5*Aspect
        #                  - theta6*Water - theta7*Humidity)
        # Multiplied by has_burning_neighbour to zero out
        # cells that are not adjacent to any burning cell
        p_spread = self._sigmoid(
        1.5 * neighbour_fire                    # theta1 * N(i,j)
        + 1.2 * wind_influence                    # theta2 * Wind
        + 1.0 * self.fuel_map * slope_multiplier  # theta3 * Fuel * slope
        + 0.8 * self.slope_map                    # theta4 * Slope
        + 0.3 * self.aspect_map                   # theta5 * Aspect
        - 2.0 * self.water_map                    # theta6 * Water
        - 1.0 * self.humidity                     # theta7 * Humidity
        - 1
        ) * has_burning_neighbour

        # ── Step 6: stochastic ignition ───────────────────────────
        # Unburned cells with no water can ignite
        # Unburned cells with water = permanent firebreak
        unburned      = (self.fire_map == 0.0) & (self.water_map < 0.5)
        random_roll   = np.random.rand(self.height, self.width)
        new_ignitions = unburned & (random_roll < p_spread * alpha)

        # ── Step 7: burnout ───────────────────────────────────────
        # Low fuel cells burn out faster than high fuel cells
        # delta * (1 - fuel) → sparse scrub burns out quickly
        #                     → dense forest persists longer
        burnout_chance = delta * (1.0 - self.fuel_map)
        random_burnout = np.random.rand(self.height, self.width)
        new_burnouts   = burning & (random_burnout < burnout_chance)

        # ── Step 8: apply updates to a COPY of fire_map ──────────
        # Must work on copy — updating in place would allow
        # newly ignited cells to spread again in the same step
        new_fire = self.fire_map.copy()
        new_fire[new_ignitions] = 1.0   # newly ignited cells
        new_fire[new_burnouts]  = 2.0   # burned out cells
        self.fire_map = new_fire


    def _sigmoid(self, x):
        return 1.0 / (1.0 + np.exp(-x))


    def _compute_reward(self, row, col, new_burned, prev_burning, curr_burning, was_burning):
        reward = 0.0

        # Timestep penalty
        reward -= 0.001

        # Fire spreading is bad
        reward -= new_burned * 0.05

        # Genuine suppression
        if was_burning and self.fire_map[row, col] == 0.0:
            reward += 0.2

        # Fire shrinking
        if curr_burning < prev_burning:
            reward += 0.1

        # Win condition
        if np.sum(self.fire_map == 1.0) == 0:
            reward += 1.0
        
        # In _compute_reward
        if was_burning and self.fire_map[row, col] == 0.0:
            reward += 1.0    # up from 0.2 — make suppression much more attractive

        if curr_burning < prev_burning:
            reward += 0.5    # up from 0.1
            
        if np.sum(self.fire_map == 1.0) == 0:
            reward += 5.0    # up from 1.0

        return reward


    def _near_fire(self, row, col, radius=3):
        """Check if a cell is within radius of any burning cell."""
        r0 = max(0, row - radius)
        r1 = min(self.height, row + radius + 1)
        c0 = max(0, col - radius)
        c1 = min(self.width,  col + radius + 1)
        return bool(np.any(self.fire_map[r0:r1, c0:c1] == 1.0))
    
    def action_masks(self):
        """
        Returns a boolean mask of valid actions.
        True  = agent CAN spray this cell
        False = agent CANNOT spray this cell (already saturated)
        """
        # Flatten water map — cells with water >= 1.0 are fully saturated
        # Cells with fire_map == 2.0 are burned out — no point spraying
        valid = (self.water_map < 1.0) & (self.fire_map != 2.0)
        return valid.flatten()
    
    
    def show(self):
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches
        from matplotlib.colors import LightSource
        import numpy as np
        import os

        # ── Create figure once ────────────────────────────────────────
        if not hasattr(self, '_fig') or not plt.fignum_exists(self._fig.number):
            self._fig = plt.figure(figsize=(9, 9), facecolor='black')
            self._ax  = self._fig.add_axes([0.03, 0.06, 0.94, 0.88])
            plt.ion()
            plt.show(block=False)
            self._frames_dir = "/content/drive/MyDrive/FOREST FIRE RL/frames"
            os.makedirs(self._frames_dir, exist_ok=True)
            self._frame_count = 0

        self._ax.cla()

        # ── Layer 1: Hillshaded terrain base ──────────────────────────
        # LightSource simulates sunlight hitting the elevation model
        # azdeg=315 = light from northwest, altdeg=45 = 45 degree angle
        ls        = LightSource(azdeg=315, altdeg=45)
        hillshade = ls.hillshade(self.elevation_map, vert_exag=4.0)

        # Keep minimum brightness — shadowed areas still visible
        hillshade = 0.35 + 0.65 * hillshade

        # ── Layer 2: Fuel-based landscape color ───────────────────────
        # YlGn: yellow = sparse scrub, deep green = dense forest
        fuel_rgb = plt.cm.YlGn(self.fuel_map)[:, :, :3]

        # Multiply color by hillshade — mountains cast shadows
        terrain_rgb = np.clip(fuel_rgb * hillshade[:, :, np.newaxis], 0, 1)
        self._ax.imshow(terrain_rgb, interpolation='bilinear', aspect='auto')

        # ── Layer 3: Burned scar (charcoal overlay) ───────────────────
        burned_out = (self.fire_map == 2.0)
        if burned_out.any():
            scar      = np.zeros((*self.fire_map.shape, 4), dtype=np.float32)
            scar[burned_out] = [0.10, 0.08, 0.08, 0.88]  # dark charcoal
            self._ax.imshow(scar, interpolation='nearest', aspect='auto')

        # ── Layer 4: Water / firebreak (blue overlay) ─────────────────
        water_cells = self.water_map >= 0.5
        if water_cells.any():
            water_rgba = np.zeros((*self.water_map.shape, 4), dtype=np.float32)
            water_rgba[water_cells] = [0.05, 0.45, 1.0, 0.80]  # bright blue
            self._ax.imshow(water_rgba, interpolation='nearest', aspect='auto')

        # ── Layer 5: Active fire (orange/yellow glow) ─────────────────
        burning = (self.fire_map == 1.0)
        if burning.any():
            fire_rgba = np.zeros((*self.fire_map.shape, 4), dtype=np.float32)

            # Fire colour varies with fuel density:
            # Dense forest burns brighter yellow, sparse scrub is darker orange
            intensity = 0.3 + 0.7 * self.fuel_map  # 0.3 min so all fire visible

            fire_rgba[:, :, 0] = 1.0               # Red   = full
            fire_rgba[:, :, 1] = intensity * 0.45  # Green = varies (orange → yellow)
            fire_rgba[:, :, 2] = 0.0               # Blue  = none
            fire_rgba[:, :, 3] = 0.0               # Alpha = 0 for non-burning cells

            fire_rgba[burning, 3] = 0.95            # Alpha = opaque for burning cells
            self._ax.imshow(fire_rgba, interpolation='nearest', aspect='auto')

        # ── Layer 6: Fire edge glow (soft halo around fire) ───────────
        # Dilate burning mask slightly for a glow effect
        if burning.any():
            from scipy.ndimage import uniform_filter
            glow = uniform_filter(burning.astype(np.float32), size=3)
            glow_rgba = np.zeros((*self.fire_map.shape, 4), dtype=np.float32)
            glow_mask = (glow > 0) & ~burning  # adjacent to fire but not on fire
            glow_rgba[glow_mask] = [1.0, 0.3, 0.0, 0.25]  # faint orange halo
            self._ax.imshow(glow_rgba, interpolation='bilinear', aspect='auto')

        # ── Stats title ───────────────────────────────────────────────
        n_burning  = int(np.sum(self.fire_map == 1.0))
        n_burned   = int(np.sum(self.fire_map == 2.0))
        burned_pct = n_burned / self.n_cells * 100

        self._ax.set_title(
            f"Sierra Nevada Wildfire  —  Step {self.step_count:>3d}"
            f"     Burning: {n_burning:>4d}"
            f"     Burned: {n_burned:>4d}  ({burned_pct:.1f}%)"
            f"     Suppressed: {self.total_suppressed}",
            color='white', fontsize=10, fontfamily='monospace',
            pad=7, loc='center'
        )

        # ── Legend ────────────────────────────────────────────────────
        legend_items = [
            mpatches.Patch(facecolor='#3a7d44', edgecolor='white', label='Dense forest'),
            mpatches.Patch(facecolor='#c8c84a', edgecolor='white', label='Sparse scrub'),
            mpatches.Patch(facecolor='#FF5500', edgecolor='white', label='Active fire'),
            mpatches.Patch(facecolor='#1a1212', edgecolor='grey',  label='Burned scar'),
            mpatches.Patch(facecolor='#0A72FF', edgecolor='white', label='Water / firebreak'),
        ]
        self._ax.legend(
            handles=legend_items,
            loc='lower right',
            fontsize=8,
            facecolor='#111111',
            edgecolor='#555555',
            labelcolor='white',
            framealpha=0.85,
            borderpad=0.8
        )

        self._ax.axis('off')
        self._fig.patch.set_facecolor('black')
        self._ax.set_facecolor('black')

        self._fig.canvas.draw()
        self._fig.canvas.flush_events()

        # ── Save frame ────────────────────────────────────────────────
        frame_path = os.path.join(
            self._frames_dir, f"frame_{self._frame_count:04d}.png"
        )
        self._fig.savefig(
            frame_path, dpi=100,
            bbox_inches='tight',
            facecolor='black'
        )
        self._frame_count += 1