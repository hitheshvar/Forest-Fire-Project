import sys
import os
import glob
import matplotlib
matplotlib.use('Agg')  # ← no display needed, renders to file only
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import LightSource
import numpy as np
import imageio

sys.path.append('/content/drive/MyDrive/FOREST FIRE RL')
from fire_sim.env import ForestFireEnv
from stable_baselines3 import PPO

CONFIG     = '/content/drive/MyDrive/FOREST FIRE RL/fire_sim/config.yaml'
MODEL      = '/content/drive/MyDrive/FOREST FIRE RL/models/ppo_fire_masked_v1.zip'
FRAMES_DIR = '/content/drive/MyDrive/FOREST FIRE RL/frames'
GIF_PATH   = '/content/drive/MyDrive/FOREST FIRE RL/fire_episode.gif'

os.makedirs(FRAMES_DIR, exist_ok=True)
for f in glob.glob(os.path.join(FRAMES_DIR, "frame_*.png")):
    os.remove(f)

env   = ForestFireEnv(config_path=CONFIG)
model = PPO.load('/content/drive/MyDrive/FOREST FIRE RL/models/ppo_fire_final', env=env)
print("Model loaded ✓")

obs, _ = env.reset()

def save_frame(frame_count, step, info=None):
    fig, ax = plt.subplots(1, 1, figsize=(8, 8), facecolor='black')

    # Hillshaded terrain
    ls        = LightSource(azdeg=315, altdeg=45)
    hillshade = ls.hillshade(env.elevation_map, vert_exag=4.0)
    hillshade = 0.35 + 0.65 * hillshade
    fuel_rgb    = plt.cm.YlGn(env.fuel_map)[:, :, :3]
    terrain_rgb = np.clip(fuel_rgb * hillshade[:, :, np.newaxis], 0, 1)
    ax.imshow(terrain_rgb, interpolation='bilinear', aspect='auto')

    # Burned scar
    burned_out = (env.fire_map == 2.0)
    if burned_out.any():
        scar = np.zeros((*env.fire_map.shape, 4), dtype=np.float32)
        scar[burned_out] = [0.10, 0.08, 0.08, 0.88]
        ax.imshow(scar, interpolation='nearest', aspect='auto')

    # Water
    water_cells = env.water_map >= 0.5
    if water_cells.any():
        water_rgba = np.zeros((*env.water_map.shape, 4), dtype=np.float32)
        water_rgba[water_cells] = [0.05, 0.45, 1.0, 0.80]
        ax.imshow(water_rgba, interpolation='nearest', aspect='auto')

    # Active fire
    burning = (env.fire_map == 1.0)
    if burning.any():
        fire_rgba = np.zeros((*env.fire_map.shape, 4), dtype=np.float32)
        intensity = 0.3 + 0.7 * env.fuel_map
        fire_rgba[burning, 0] = 1.0
        fire_rgba[burning, 1] = intensity[burning] * 0.45
        fire_rgba[burning, 3] = 0.95
        ax.imshow(fire_rgba, interpolation='nearest', aspect='auto')

    # Glow
    from scipy.ndimage import uniform_filter
    if burning.any():
        glow      = uniform_filter(burning.astype(np.float32), size=3)
        glow_rgba = np.zeros((*env.fire_map.shape, 4), dtype=np.float32)
        glow_mask = (glow > 0) & ~burning
        glow_rgba[glow_mask] = [1.0, 0.3, 0.0, 0.25]
        ax.imshow(glow_rgba, interpolation='bilinear', aspect='auto')

    # Stats
    n_burning = int(np.sum(env.fire_map == 1.0))
    n_burned  = int(np.sum(env.fire_map == 2.0))
    burned_pct = n_burned / env.n_cells * 100
    ax.set_title(
        f"Sierra Nevada — Step {step:>3d}  |  "
        f"Burning: {n_burning:>4d}  |  "
        f"Burned: {n_burned:>4d} ({burned_pct:.1f}%)",
        color='white', fontsize=10, fontfamily='monospace', pad=7
    )

    # Legend
    legend_items = [
        mpatches.Patch(facecolor='#3a7d44', edgecolor='white', label='Dense forest'),
        mpatches.Patch(facecolor='#c8c84a', edgecolor='white', label='Sparse scrub'),
        mpatches.Patch(facecolor='#FF5500', edgecolor='white', label='Active fire'),
        mpatches.Patch(facecolor='#1a1212', edgecolor='grey',  label='Burned scar'),
        mpatches.Patch(facecolor='#0A72FF', edgecolor='white', label='Water / firebreak'),
    ]
    ax.legend(handles=legend_items, loc='lower right', fontsize=8,
              facecolor='#111111', edgecolor='#555555', labelcolor='white',
              framealpha=0.85)
    ax.axis('off')
    ax.set_facecolor('black')

    path = os.path.join(FRAMES_DIR, f"frame_{frame_count:04d}.png")
    fig.savefig(path, dpi=80, bbox_inches='tight', facecolor='black')
    plt.close(fig)  # ← critical in Colab — close each figure immediately
    return path

# Run episode
frame_count = 0
total_reward = 0
step = 0

save_frame(frame_count, step)
frame_count += 1

while True:
    action, _ = model.predict(obs, deterministic=True)
    obs, reward, terminated, truncated, info = env.step(int(action))
    total_reward += reward
    step += 1

    save_frame(frame_count, step, info)
    frame_count += 1

    print(f"Step {step:3d} | Action: {action:5d} | "
          f"Reward: {reward:6.2f} | "
          f"Burning: {info['burning']:4d} | "
          f"Burned%: {info['burned_pct']:.1%}")

    if terminated or truncated:
        print(f"\nEpisode done — Total reward: {total_reward:.2f}")
        break

# Create GIF
print("\nCreating GIF...")
frame_files = sorted(glob.glob(os.path.join(FRAMES_DIR, "frame_*.png")))
images = [imageio.imread(f) for f in frame_files]
imageio.mimsave(GIF_PATH, images, fps=4)
print(f"GIF saved ✓  ({len(frame_files)} frames)")