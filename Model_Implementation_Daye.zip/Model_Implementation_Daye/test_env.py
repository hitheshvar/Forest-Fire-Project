import sys
sys.path.append(r"C:\Users\peter\Documents\ANGLIA\MACHINE LEARNING\PROJECT\RL")

from fire_sim.env import ForestFireEnv
import numpy as np

# ── Initialise environment ────────────────────────────────────
env = ForestFireEnv(config_path=r"C:\Users\peter\Documents\ANGLIA\MACHINE LEARNING\PROJECT\RL\fire_sim\config.yaml")

print("Environment created ✓")
print(f"Observation space: {env.observation_space.shape}")
print(f"Action space:      {env.action_space.n}")

# ── Reset ─────────────────────────────────────────────────────
obs, info = env.reset()
print(f"\nReset complete ✓")
print(f"Obs shape:         {obs.shape}")
print(f"Ignition cell:     {env.initial_fire_cell}")
print(f"Fire cells at t=0: {np.sum(env.fire_map == 1.0)}")

# ── Run 10 random steps ───────────────────────────────────────
print("\nRunning 10 random steps...")
total_reward = 0

for step in range(10):
    action = env.action_space.sample()   # random action
    obs, reward, terminated, truncated, info = env.step(action)
    total_reward += reward

    print(f"  Step {step+1:2d} | action={action:6d} | "
          f"reward={reward:8.1f} | "
          f"burning={info['burning']:4d} | "
          f"burned={info['burned']:4d} | "
          f"burned_pct={info['burned_pct']:.1%}")

    if terminated or truncated:
        print("  Episode ended early")
        break

print(f"\nTotal reward over 10 steps: {total_reward:.1f}")
print("\nSanity check passed ✓" if total_reward != 0 else "\nWarning: reward is 0, check reward function")