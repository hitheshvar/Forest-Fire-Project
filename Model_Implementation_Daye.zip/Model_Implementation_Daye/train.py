import sys
sys.path.append(r"C:\Users\peter\Documents\ANGLIA\MACHINE LEARNING\PROJECT\RL")

from fire_sim.env import ForestFireEnv
from stable_baselines3 import DQN
from stable_baselines3.common.env_checker import check_env
from stable_baselines3.common.monitor import Monitor
import os

CONFIG    = r"C:\Users\peter\Documents\ANGLIA\MACHINE LEARNING\PROJECT\RL\fire_sim\config.yaml"
LOG_DIR   = r"C:\Users\peter\Documents\ANGLIA\MACHINE LEARNING\PROJECT\RL\logs"
MODEL_DIR = r"C:\Users\peter\Documents\ANGLIA\MACHINE LEARNING\PROJECT\RL\models"
os.makedirs(LOG_DIR,   exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

print("Creating environment...")
env = ForestFireEnv(config_path=CONFIG)
env = Monitor(env, LOG_DIR)

print("Checking environment-..")
check_env(env, warn=True)
print("Environment check passed")

print("\nCreating DQN agent...")
model = DQN(
    policy                 = "CnnPolicy",
    env                    = env,
    learning_rate          = 1e-4,       # ← up from 5e-5
    buffer_size            = 10_000,     # ← down from 20,000 (memory)
    learning_starts        = 5_000,      # ← up from 1,000
    batch_size             = 32,         # ← down from 64 (memory)
    gamma                  = 0.99,
    exploration_fraction   = 0.7,        # ← up from 0.4
    exploration_final_eps  = 0.15,        # ← up from 0.05
    train_freq             = 4,
    target_update_interval = 1000,
    verbose                = 1,
    tensorboard_log        = LOG_DIR,
    policy_kwargs          = {"normalize_images": False}
)

print("DQN agent created")
model.learn(
    total_timesteps = 50_000,    
    log_interval    = 10,           # less frequent logging
    progress_bar    = True,
)

save_path = os.path.join(MODEL_DIR, "dqn_fire_v6")
model.save(save_path)
print(f"\nModel saved to {save_path}")