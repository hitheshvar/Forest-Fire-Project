import sys
sys.path.append('/content/drive/MyDrive/FOREST FIRE RL')

from fire_sim.env import ForestFireEnv
from sb3_contrib import MaskablePPO
from sb3_contrib.common.wrappers import ActionMasker
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.callbacks import CheckpointCallback
import os

CONFIG    = '/content/drive/MyDrive/FOREST FIRE RL/fire_sim/config.yaml'
LOG_DIR   = '/content/drive/MyDrive/FOREST FIRE RL/logs'
MODEL_DIR = '/content/drive/MyDrive/FOREST FIRE RL/models'
os.makedirs(LOG_DIR,   exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

# ── Mask function ─────────────────────────────────────────────
def mask_fn(env):
    return env.action_masks()

# ── Create environment ────────────────────────────────────────
print("Creating environment...")
env = ForestFireEnv(config_path=CONFIG)
env = ActionMasker(env, mask_fn)
env = Monitor(env, LOG_DIR)
print("Environment created ✓")

# ── Create checkpoint callback ────────────────────────────────
checkpoint = CheckpointCallback(
    save_freq   = 50_000,
    save_path   = MODEL_DIR,
    name_prefix = "ppo_masked"
)

# ── Create model ──────────────────────────────────────────────
print("\nCreating MaskablePPO agent...")
model = MaskablePPO(
    policy          = "CnnPolicy",
    env             = env,
    learning_rate   = 3e-4,
    n_steps         = 2048,
    batch_size      = 256,
    n_epochs        = 10,
    gamma           = 0.99,
    gae_lambda      = 0.95,
    clip_range      = 0.2,
    ent_coef        = 0.05,
    verbose         = 1,
    tensorboard_log = LOG_DIR,
    policy_kwargs   = {"normalize_images": False}
)
print("Agent created ✓")

# ── Train ─────────────────────────────────────────────────────
print("\nStarting training...")
model.learn(
    total_timesteps = 1_000_000,
    callback        = checkpoint,
    progress_bar    = True,
)

# ── Save ──────────────────────────────────────────────────────
save_path = os.path.join(MODEL_DIR, "ppo_fire_masked_v1")
model.save(save_path)
print(f"\nModel saved to {save_path} ✓")