import sys
import os
import glob
import matplotlib.pyplot as plt
import imageio
sys.path.append(r"C:\Users\peter\Documents\ANGLIA\MACHINE LEARNING\PROJECT\RL")

from fire_sim.env import ForestFireEnv
from stable_baselines3 import DQN

CONFIG     = r"C:\Users\peter\Documents\ANGLIA\MACHINE LEARNING\PROJECT\RL\fire_sim\config.yaml"
MODEL      = r"C:\Users\peter\Documents\ANGLIA\MACHINE LEARNING\PROJECT\RL\models\dqn_fire_v6"
FRAMES_DIR = r"C:\Users\peter\Documents\ANGLIA\MACHINE LEARNING\PROJECT\RL\frames"
GIF_PATH   = r"C:\Users\peter\Documents\ANGLIA\MACHINE LEARNING\PROJECT\RL\fire_episode_v6.gif"

# Clean up old frames
os.makedirs(FRAMES_DIR, exist_ok=True)
for f in glob.glob(os.path.join(FRAMES_DIR, "frame_*.png")):
    os.remove(f)
print("Frames folder cleared")

# Load environment and model
env = ForestFireEnv(config_path=CONFIG)
model = DQN.load(MODEL, env=env)
print("Model loaded")

# Create figure once
fig, axes = plt.subplots(1, 4, figsize=(14, 4))
plt.ion()
plt.show(block=False)
frame_count = 0

def save_frame(step, info=None):
    global frame_count

    for ax in axes:
        ax.cla()

    # Panel 1 — Fire state
    axes[0].imshow(env.fire_map, cmap="hot", vmin=0, vmax=2)
    axes[0].set_title(
        f"Fire State\n"
        f"Burning: {int((env.fire_map==1).sum())}  "
        f"Burned: {int((env.fire_map==2).sum())}",
        fontsize=9
    )
    axes[0].axis("off")

    # Panel 2 — Water deployed
    axes[1].imshow(env.water_map, cmap="Blues", vmin=0, vmax=1)
    axes[1].set_title(f"Water Deployed\nStep: {env.step_count}", fontsize=9)
    axes[1].axis("off")

    # Panel 3 — Fuel map
    axes[2].imshow(env.fuel_map, cmap="Greens", vmin=0, vmax=1)
    axes[2].set_title("Fuel Map", fontsize=9)
    axes[2].axis("off")

    # Panel 4 — Elevation
    axes[3].imshow(env.elevation_map, cmap="terrain", vmin=0, vmax=1)
    axes[3].set_title("Elevation", fontsize=9)
    axes[3].axis("off")

    title = f"Sierra Nevada Fire — Step {step}"
    if info:
        title += f"  |  Burned: {info['burned_pct']:.1%}"
    fig.suptitle(title, fontsize=11)

    fig.canvas.draw()
    fig.canvas.flush_events()

    # Save frame to disk
    frame_path = os.path.join(FRAMES_DIR, f"frame_{frame_count:04d}.png")
    fig.savefig(frame_path, dpi=80, bbox_inches="tight")
    frame_count += 1

# Run episode  
obs, _ = env.reset()
save_frame(step=0)

total_reward = 0
step = 0

print("\nRunning episode...")
while True:
    action, _ = model.predict(obs, deterministic=True)
    obs, reward, terminated, truncated, info = env.step(int(action))
    total_reward += reward
    step += 1

    save_frame(step=step, info=info)

    print(f"  Step {step:3d} | Action: {action:5d} | "
          f"Reward: {reward:7.2f} | "
          f"Burning: {info['burning']:4d} | "
          f"Burned%: {info['burned_pct']:.1%}")

    if terminated or truncated:
        print(f"\nEpisode ended — Total reward: {total_reward:.2f}")
        break

plt.ioff()
plt.close()

# ── Stitch frames into GIF ────────────────────────────────────
print("\nCreating animation...")
frame_files = sorted(glob.glob(os.path.join(FRAMES_DIR, "frame_*.png")))

if len(frame_files) == 0:
    print("No frames found — check frames folder")
else:
    images = [imageio.imread(f) for f in frame_files]
    imageio.mimsave(GIF_PATH, images, fps=4)
    print(f"GIF saved to {GIF_PATH}")
    print(f"Total frames: {len(frame_files)}")

plt.show(block=True)